<?php $__env->startSection('content'); ?>
    <div class="container">
        <form action="add" method="POST">
            <?php echo e(csrf_field()); ?>


            <div class="form-group">
                <label for="usr">title:</label>
                <input type="text" name="title" class="form-control">
            </div>
            <div class="form-group">
                <label for="usr">body:</label>
                <textarea rows="4" cols="50"  name="body" class="form-control">
      </textarea>
            </div>

            </br>
            <input type="submit" value="add new" class="btn btn-primary"/>
        </form>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mybloger\resources\views/manage/AddArticle.blade.php ENDPATH**/ ?>