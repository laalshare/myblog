<?php $__env->startSection('content'); ?>
    <div class="container">
        <table class="table table-striped">
            <tr>
                <td> Title</td>
            </tr>

            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $art): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <a href="<?php echo e("/read/".$art->id); ?>"><?php echo e($art->title); ?></a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </table>

        <a href="add">Add new article</a>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mybloger\resources\views/manage/view.blade.php ENDPATH**/ ?>